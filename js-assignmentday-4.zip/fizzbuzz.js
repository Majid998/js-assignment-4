console.log("FizzBUzz");

for (let i = 1; i<=100; i++)//creating a loop to start from 0 and go up to 100
{
    if(i % 3 == 0) // to check whether the number is divisible by 3
    {
        console.log(`${i} -> Fizz`);//if the number is divisible by 3 then print Fizz.
    }
    if(i % 5 == 0)// to check Whether the number is divisible by 5
    {
    
        console.log(`${i} -> Buzz`); //if the number is divisible by 5 then print Buzz.
    }
    if(i % 3 == 0 && i % 5 == 0)
    {
        console.log(`${i} -> FizzBuzz`);
    }
   else
   { 
       console.log(i-1);
   }
}
