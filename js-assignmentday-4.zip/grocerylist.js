console.log('Grocery List');

 let groceryList =['milk', 'bread', 'sugar','eggs','juice','biscuits'];
 let size = groceryList.length;
 console.log(groceryList);

 let shoppingBasket = [];

 for (let i = 0; i <= size-1 ; i++)
 {
    
        shoppingBasket[i] = groceryList[i];
       //  console.log('pringting the shoppingBasket list');
       //  console.log(shoppingBasket);

 } 
 console.log("printing the shoppingBasket list");
 console.log(shoppingBasket);
 shoppingBasket.push("ice-cream","chocolate","peanut-butter",);
 console.log("printing the updated shoppingBasket list");
 console.log(shoppingBasket);